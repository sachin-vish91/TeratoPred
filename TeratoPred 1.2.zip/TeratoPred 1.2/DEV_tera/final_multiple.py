
# coding: utf-8

# # Teratogenicity Prediction model 21.7.16
# 
# 

# In[100]:


import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit import DataStructs
from rdkit.Chem import AllChem
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn import model_selection
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neighbors import kneighbors_graph
from sklearn.model_selection import cross_val_predict
from sklearn import preprocessing
from sklearn.externals import joblib
from sklearn.pipeline import Pipeline
import sys



# In[107]:

h =raw_input("Please enter the file with Name and SMILES column of query mols: ")
g = h+'.csv' 
data = pd.read_csv(g, sep=',')
print data.shape
data.head()
y = data.VALUES.values

a =raw_input("Please enter the type of descriptor that you wish to use for the model: " )
b = a+'.csv'
df = pd.read_csv(b, sep=',')
del df['Name']
df.head()
X=np.array(df)
X.shape








# # SSS

# In[108]:

sss = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=0)
for train_index, test_index in sss.split(X, y):
	out = ("TRAIN:", train_index, "TEST:", test_index)
	X_tr, X_xt = X[train_index], X[test_index]
	y_tr, y_xt = y[train_index], y[test_index]
	print X_tr.shape, X_xt.shape
	print y_tr.shape, y_xt.shape


# # RFE

# In[109]:

model = LogisticRegression()
rfe = RFE(model, 20)
X_rfe = rfe.fit(X_tr, y_tr)
X_tr_rfe = rfe.transform(X_tr)
X_xt_rfe = rfe.transform(X_xt)
X_tr_rfe.shape, X_xt_rfe.shape


# In[110]:

features=np.array(list(df))
selected_features=features[rfe.get_support()]
selected_features.tofile('Top 20 selected features.csv')
selected_features


# # Validation Parameters

# In[111]:

def calc_performance(y_true, y_pred, labels=[1, 0]):
    TP=0
    FN=0
    FP=0
    TN=0
    for i in range(len(y_true)):
        if (y_true[i] == labels[0] and y_pred[i] == labels[0]): TP += 1.0
        if (y_true[i] == labels[0] and y_pred[i] == labels[1]): FN += 1.0
        if (y_true[i] == labels[1] and y_pred[i] == labels[0]): FP += 1.0
        if (y_true[i] == labels[1] and y_pred[i] == labels[1]): TN += 1.0  

    recall = TP/(TP+FN)
    specificity = TN/(TN+FP)
    try: precision = TP/(TP+FP)
    except: precision = 0
    accuracy = (TP+TN)/(TP+FP+TN+FN)
    #balanced_acc = (recall+specificity)/2.0
    try: f1_score = 2*(recall*precision)/(recall+precision)
    except: f1_score = 0
    try: mcc = (TP*TN-FP*FN)/((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))**0.5
    except: mcc = 0
    diff = abs(recall-specificity)
    if diff < 0.005: diff = 0.005
    #balanced_classification_rate = balanced_acc
    return [ round(recall,4), round(specificity,4), 
            round(precision,4), round(accuracy,4), round(f1_score,4), round(mcc,4),int(sum(y_true)), int(len(y_true)-sum(y_true))]


# # Model

# In[112]:

skf5 = model_selection.StratifiedKFold(n_splits=5, shuffle=True, random_state=0)


temp = []

for i in [3,5,7]:
    knn=  KNeighborsClassifier(n_neighbors=i, weights='uniform', metric = 'minkowski' ,algorithm='auto', leaf_size=60, p=2, n_jobs=2)

    knn.fit(X_tr_rfe, y_tr)
    y_pred= knn.predict(X_tr_rfe)
    temp.append([i, 'Train']+calc_performance(y_tr, y_pred))

    y_pred = cross_val_predict(knn, X_tr_rfe, y_tr, cv=skf5, n_jobs=1)
    temp.append([i, '5 fold CV']+calc_performance(y_tr, y_pred))
    
    #y_pred = cross_val_predict(knn, X_tr_rfe, y_tr, cv=skf10, n_jobs=1)
    #temp.append([i, '10 fold CV']+calc_performance(y_tr, y_pred))

    knn.fit(X_tr_rfe, y_tr)
    y_pred = knn.predict(X_xt_rfe)
    temp.append([i, 'External Validation']+calc_performance(y_xt, y_pred))

result = pd.DataFrame(temp, columns=['neighbors','dataset','Recall', 'Specificity', 'Precision', 
                                    'Accuracy', 'f1_score', 'MCC', '1s', '0s'])


# In[113]:

#result


# In[114]:

ext = knn.predict(X_xt_rfe)


# In[116]:

joblib.dump(data, "TeratoPred_data.pkl")
joblib.dump(knn,"TeratoPred_model.pkl")
joblib.dump(RFE, "TeratoPred_selector.pkl")


# # Predict

# In[117]:

load_data = joblib.load("TeratoPred_data.pkl")
load_selector = joblib.load("TeratoPred_selector.pkl")
load_model = joblib.load("TeratoPred_model.pkl")


# In[119]:

a1= ""
a1 = raw_input("Please input dataset of query molecules :")
a2 = a1+'.csv'
data2 = pd.read_csv(a2, sep=',')

print data2.shape



# In[120]:

b1 = ""
b1 = raw_input("Please input the name of PaDEL descriptor file in csv format :")
b2=b1+'.csv'
desc_user = pd.read_csv(b2, sep=',')

del desc_user['Name']
desc_user.head()



# In[121]:

X1=np.array(desc_user)
X1.shape


# In[122]:

model = LogisticRegression()
rfe = RFE(model, 20)
X_rfe = rfe.fit(X_tr, y_tr)
X_tr_rfe = rfe.transform(X_tr)
X_predict = rfe.transform(X1)
X_tr_rfe.shape, X_xt_rfe.shape


# In[123]:

features=np.array(list(desc_user))
selected_features1=features[rfe.get_support()]
#selected_features.tofile('Top 20 selected features.csv')
selected_features1


# In[124]:

result1 = load_model.predict(X_predict)


# In[125]:

result1


# In[126]:

nom= data2.Name.values
df_nom=pd.DataFrame(data=nom,columns=['Name'])
df_nom.head()


# In[127]:

output = pd.DataFrame(data=result1, columns=['Predicted Values'])
output['Name'] = data2.Name.values
output.head()


# In[128]:

output.to_csv("Teratogenicity Prediction of Query.csv")


# In[ ]:



