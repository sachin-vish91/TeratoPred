
# coding: utf-8

# In[1]:


import sys
import pandas as pd
import pickle
import numpy as np
from rdkit import DataStructs
from rdkit import Chem
from rdkit.Chem import AllChem
from sklearn.model_selection import cross_val_predict
from sklearn import preprocessing
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn import model_selection
from sklearn.externals import joblib
from sklearn.neighbors import KNeighborsClassifier

p = str(sys.argv[1])
q = str(sys.argv[2])
# In[2]:

#h =raw_input("Please enter the file with SMILES: ")
g = 'C:\\Users\\Sachin\\Desktop\\DEV_tera\\teratopred database.csv' 
data = pd.read_csv(g, sep=',')

#print data.shape
data.head()
y = data.VALUES.values


# In[3]:

def GetFpArray(fps):
    fps1 = []
    for fp in fps:
        arr = np.zeros((1,))
        DataStructs.ConvertToNumpyArray(fp, arr)
        fps1.append(arr)
    X = np.asarray(fps1, dtype=np.int)
    #print X.shape
    return X


# In[4]:

names = pd.read_csv('C:\\Users\\Sachin\\Desktop\\DEV_tera\\Maccs_headers.csv', sep = ',')


Mck = []

for s in data.SMILES.values:
    m = Chem.MolFromSmiles(s)
    AllChem.Compute2DCoords(m)
    
    Mck.append(AllChem.GetMACCSKeysFingerprint(m))



# In[5]:

Mck =  (GetFpArray(Mck))
np.savetxt('C:\\Users\\Sachin\\Desktop\\DEV_tera\\Maccs_keys.csv',Mck,delimiter=',')


# In[6]:

df = pd.read_csv('C:\\Users\\Sachin\\Desktop\\DEV_tera\\Maccs_keys.csv', sep=',', names=(names))
df.head()


# In[7]:

X = np.asarray(df)
#print X.shape


# In[8]:

sss = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=0)
for train_index, test_index in sss.split(X, y):
	out = ("TRAIN:", train_index, "TEST:", test_index)
	X_tr, X_xt = X[train_index], X[test_index]
	y_tr, y_xt = y[train_index], y[test_index]
	#print X_tr.shape, X_xt.shape
	#print y_tr.shape, y_xt.shape


# In[9]:

model = LogisticRegression()
rfe = RFE(model, 20)
X_rfe = rfe.fit(X_tr, y_tr)
X_tr_rfe = rfe.transform(X_tr)
X_xt_rfe = rfe.transform(X_xt)
X_tr_rfe.shape, X_xt_rfe.shape
features=np.array(list(df))
selected_features=features[rfe.get_support()]
#selected_features.tofile('Selected_features_20.txt')
selected_features


# In[10]:

def calc_performance(y_true, y_pred, labels=[1, 0]):
    TP=0
    FN=0
    FP=0
    TN=0
    for i in range(len(y_true)):
        if (y_true[i] == labels[0] and y_pred[i] == labels[0]): TP += 1.0
        if (y_true[i] == labels[0] and y_pred[i] == labels[1]): FN += 1.0
        if (y_true[i] == labels[1] and y_pred[i] == labels[0]): FP += 1.0
        if (y_true[i] == labels[1] and y_pred[i] == labels[1]): TN += 1.0  

    recall = TP/(TP+FN)
    specificity = TN/(TN+FP)
    try: precision = TP/(TP+FP)
    except: precision = 0
    accuracy = (TP+TN)/(TP+FP+TN+FN)
    #balanced_acc = (recall+specificity)/2.0
    try: f1_score = 2*(recall*precision)/(recall+precision)
    except: f1_score = 0
    try: mcc = (TP*TN-FP*FN)/((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))**0.5
    except: mcc = 0
    diff = abs(recall-specificity)
    if diff < 0.005: diff = 0.005
    #balanced_classification_rate = balanced_acc
    return [ round(recall,4), round(specificity,4), 
            round(precision,4), round(accuracy,4), round(f1_score,4), round(mcc,4),int(sum(y_true)),
            int(len(y_true)-sum(y_true))] 


# In[11]:

skf5 = model_selection.StratifiedKFold(n_splits=5, shuffle=True, random_state=0)

temp=[]

clf = KNeighborsClassifier(n_neighbors=3, weights='uniform', metric = 'manhattan' ,algorithm='auto', leaf_size=30, p=2, n_jobs=2)

model1 = clf.fit(X_tr_rfe, y_tr)
y_pred= clf.predict(X_tr_rfe)
temp.append(['Train']+calc_performance(y_tr, y_pred))

y_pred = cross_val_predict(clf, X_tr_rfe, y_tr, cv=skf5, n_jobs=1)
temp.append(['5 fold CV']+calc_performance(y_tr, y_pred))


clf.fit(X_tr_rfe, y_tr)
y_pred = clf.predict(X_xt_rfe)
temp.append(['External Validation']+calc_performance(y_xt, y_pred))

result = pd.DataFrame(temp, columns=['dataset','Recall', 'Specificity', 'Precision', 
                                    'Accuracy', 'f1_score', 'MCC', '1s', '0s'])


# In[12]:




# In[13]:

#filename = 'Teratopred_finalized_model.sav'
#pickle.dump(model1, open(filename, 'wb'))


# In[14]:

joblib.dump(data, "Maccs_teratopred_data.pkl")
joblib.dump(model1,"Maccs_teratopred_model.pkl")
joblib.dump(rfe, "Maccs_teratopred_selector.pkl")


# In[15]:

load_data = joblib.load("Maccs_teratopred_data.pkl")
load_selector = joblib.load("Maccs_teratopred_selector.pkl")
load_model = joblib.load("Maccs_teratopred_model.pkl")


# In[17]:

#a= ""
#a = raw_input("Please input the name of query molecule :")


# In[18]:

#f= (load_data[load_data['NAME'] == a])


# In[19]:
'''
if f.values.shape.count(1)!=0:
        user_input= pd.DataFrame(data=f,columns=['CID','Name','Nephrotoxicity', 'Values', 'InChIs', 'InChi keys', 'SMILES','References'])
        #user_input.head() 
        desc = user_input.SMILES.values
        Y = user_input.Nephrotoxicity.values
else:
'''
#b= [x for x in raw_input("Kindly input the Name of the molecule and SMILE notation respectively, separated by a comma(','):").split(',')]
#print b
b = (p).split(',')
user_input1 = pd.DataFrame(data=[b], columns=["Name", "SMILES"])
user_input1.head()
        
desc = user_input1.SMILES.values


# In[20]:

user_input1


# In[21]:

def GetFpArray(fps):
    fps2 = []
    for fp in fps:
        arr = np.zeros((1,))
        DataStructs.ConvertToNumpyArray(fp, arr)
        fps2.append(arr)
    X1 = np.asarray(fps2, dtype=np.int)
    #print X1.shape
    return X1


# In[22]:

names = pd.read_csv('C:\\Users\\Sachin\\Desktop\\DEV_tera\\Maccs_headers.csv', sep = ',')
Mck1 = []


for s in desc:
    m = Chem.MolFromSmiles(s)
    AllChem.Compute2DCoords(m)
    
    Mck1.append(AllChem.GetMACCSKeysFingerprint(m))


# In[23]:

Mck1 = (GetFpArray(Mck1))
np.savetxt('C:\\Users\\Sachin\\Desktop\\DEV_tera\\Maccs_keys_1.csv',Mck1,delimiter=',')

df = pd.read_csv('C:\\Users\\Sachin\\Desktop\\DEV_tera\\Maccs_keys_1.csv', sep=',', names=(names))


# In[24]:

model = LogisticRegression()
rfe = RFE(model, 20)
X_rfe = rfe.fit(X_tr, y_tr)
X_tr_rfe = rfe.transform(X_tr)
X_predict = rfe.transform(Mck1)
X_tr_rfe.shape, X_predict.shape
features=np.array(list(df))
selected_features=features[rfe.get_support()]
#selected_features.tofile('Selected_features_20.txt')
selected_features


# In[25]:

result = load_model.predict(X_predict)


# In[27]:

print result[0]
#print 'done'
'''
if result[0] == 1:
    print 'Teratogenic'

else:
    print 'Safe'
'''

# In[ ]:



